import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Accelerometer } from 'expo-sensors';
import * as ScreenOrientation from 'expo-screen-orientation';

export default function App() {
  const [data, setData] = useState({ x: 0, y: 0, z: 0 });
  const [total, setTotal] = useState(0);

  useEffect(() => {
    ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    const sub = Accelerometer.addListener(setData); 
    return () => sub.remove (); 
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Accelerometer</Text>

      <View style={styles.levelContainer}>
        <View
          style={[
            styles.bubble,
            {
              transform: [
                { translateX: -data.x * 100 },
                { translateY: data.y * 100 },
              ],
            },
          ]}
        />
      </View>

      <View style={styles.valuesContainer}>
        <View style={[styles.card, { borderColor: '#E53935' }]}>
          <Text style={[styles.axisLabel, { color: '#E53935' }]}>X</Text>
          <Text style={styles.axisValue}>{data.x.toFixed(2)} g</Text>
        </View>

        <View style={[styles.card, { borderColor: '#43A047' }]}>
          <Text style={[styles.axisLabel, { color: '#43A047' }]}>Y</Text>
          <Text style={styles.axisValue}>{data.y.toFixed(2)} g</Text>
        </View>

        <View style={[styles.card, { borderColor: '#1E88E5' }]}>
          <Text style={[styles.axisLabel, { color: '#1E88E5' }]}>Z</Text>
          <Text style={styles.axisValue}>{data.z.toFixed(2)} g</Text>
        </View>
      </View>

      {/* Barra de fuerza total */}

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F0F4F8',
    paddingHorizontal: 16,
  },
  title: {
    fontSize: 28,
    marginBottom: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  levelContainer: {
    width: 200,
    height: 200,
    backgroundColor: '#1976D2',
    borderRadius: 100,
    borderColor: '#0D47A1',
    borderWidth: 3,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  bubble: {
    width: 40,
    height: 40,
    backgroundColor: 'lightblue',
    borderRadius: 20,
    borderColor: 'white',
    borderWidth: 2,
  },
  valuesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '90%',
    marginTop: 30,
  },
  card: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#fff',
    marginHorizontal: 5,
    borderWidth: 2,
    borderRadius: 12,
    paddingVertical: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
  },
  axisLabel: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  axisValue: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },

  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
});
