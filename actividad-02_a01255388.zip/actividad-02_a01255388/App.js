import { StyleSheet, Text, View, Image, SectionList } from 'react-native';

const Professor = (props) => {
  const randomNumber = Math.floor(Math.random() * 100 + 50);
  return (
    <View style={styles.profContainer}>
      <Image
        style={styles.profImage}
        source={{ uri: `https://picsum.photos/${randomNumber}`, width: 100, height: 100 }}
      />
      <Text style={styles.profText}> {props.name} </Text>
    </View>
  );
};

const Header = ({ title }) => (
  <View style={styles.headerContainer}>
    <Text style={styles.header}>{title}</Text>
  </View>
);

const DATA = [
  {
    title: "Profesores",
    data: [
      { id: 1, name: "Mario" },
      { id: 2, name: "Alberto" },
      { id: 3, name: "Hugo" },
      { id: 4, name: "Paco" },
      { id: 5, name: "Luis" },
      { id: 6, name: "Angélica" },
      { id: 7, name: "Alejandra" },
      { id: 8, name: "Elizabeth" },
      { id: 9, name: "Max" },
      { id: 10, name: "Nick" }
    ],
  },
  {
    title: " Alumnos",
    data: [
      { id: 1, name: "Carlos" },
      { id: 2, name: "Fernanda" },
      { id: 3, name: "Valeria" },
      { id: 4, name: "Diego" },
      { id: 5, name: "Sofía" },
      { id: 6, name: "Andrés" },
      { id: 7, name: "Camila" },
      { id: 8, name: "Patricia" },
      { id: 9, name: "Raúl" },
      { id: 10, name: "Lucía" }
    ]
  }
];

const App = () => {
  return (
    <SectionList
      sections={DATA}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => <Professor name={item.name} />}
      renderSectionHeader={({ section: { title } }) => <Header title={title} />}
    />
  );
};

export default App;

const styles = StyleSheet.create({
  profContainer: {
    flexDirection: 'row',
    padding: 10,
    margin: 10,
    alignItems: 'center',
    backgroundColor: "#f0f0f0",
    borderRadius: 8,
  },
  profImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  profText: {
    fontSize: 16,
  },
  headerContainer: {
    backgroundColor: "#4a90e2",
    padding: 8,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    color: "white",
  },
});
