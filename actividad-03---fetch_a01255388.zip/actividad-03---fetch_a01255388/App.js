// 'https://raw.githubusercontent.com/MarioDuran/react-native-course/refs/heads/main/Example3/TC2007B.json'

import { Text, View, Image, StyleSheet, SectionList, ActivityIndicator } from "react-native";
import { useState, useEffect } from "react";

const Cell = ({ name }) => {
  const randomNumber = Math.floor(Math.random() * 100 + 50);
  return (
    <View style={styles.cell}>
      <Image
        style={styles.cellImage}
        source={{ uri: `https://picsum.photos/${randomNumber}` }}
      />
      <Text style={styles.cellText}>{name}</Text>
    </View>
  );
};

const Header = ({ title }) => {
  return <Text style={styles.header}>{title}</Text>;
};

export default App = () => {
  const [isLoading, setLoading] = useState(true);
  const [sections, setSections] = useState([]);

  const getData = async () => {
    try {
      const response = await fetch(
        "https://raw.githubusercontent.com/MarioDuran/react-native-course/refs/heads/main/Example3/TC2007B.json"
      );
      const json = await response.json();
      setSections(json.TC2007B); 
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  return isLoading ? (
    <ActivityIndicator />
  ) : (
    <SectionList
      sections={sections}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => <Cell name={item.name} />}
      renderSectionHeader={({ section: { title } }) => <Header title={title} />}
    />
  );
};

const styles = StyleSheet.create({
  header: {
    fontSize: 22,
    fontWeight: "bold",
    padding: 10,
    backgroundColor: "#f2f2f2",
  },
  cell: {
    flexDirection: "row",
    padding: 10,
    margin: 5,
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
  },
  cellImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  cellText: {
    fontSize: 16,
  },
});